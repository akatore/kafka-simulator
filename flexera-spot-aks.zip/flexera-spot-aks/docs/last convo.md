I've written all the phase docs, because this last request asked me to finish every to-do. You can still do them one at a time: start with Phase 0, and tell me when you're done or stuck before moving to the next. I haven't run any of the commands; I've only written them, so expect small fixes when you try them in the playground.

All files are under `D:\Preparation\flexera-spot-aks\docs\`:

| File | Where you do it | What it covers |
|---|---|---|
| `0.plan-and-qa.md` | — | The plan and your earlier questions with answers (from before) |
| `Phase-0/0.concepts.md` | Reading, about 15 min | Spot vs on-demand vs reserved VMs, eviction, how Ocean works, office vocabulary |
| `Phase-1/1.aks-spot-nodepool.md` | KodeKloud | AKS cluster plus a Spot node pool; inspect the Spot taint, label and VM scale set |
| `Phase-2/2.workloads-on-spot.md` | KodeKloud | Tolerations, affinity, fallback to on-demand, PodDisruptionBudget, spreading, graceful shutdown |
| `Phase-3/3.simulate-eviction.md` | KodeKloud | Real eviction with `az vmss simulate-eviction`, plus a deliberately fragile app to show what an outage looks like |
| `Phase-4/4.ocean-onboarding.md` | Personal subscription | Pre-flight cost checks, connecting Azure, importing the cluster, installing the controller, Virtual Node Group, watching scaling, full teardown |
| `Phase-5/5.what-not-to-put-on-spot.md` | Reading | Which workloads to keep off Spot, Kafka/Strimzi on-demand pinning, Spot-readiness checklist |
| `office-questions.md` | At work | Questions to ask your team, with space to note the answers |

Changes and things to watch for:

- **Spot pool VM size:** Azure doesn't allow B-series VMs (like `Standard_B2s`) as Spot. The system pool still uses `B2s`, but the Spot pool uses `Standard_D2s_v3`. If the playground doesn't allow that size, the doc lists alternatives.
- **Preferred affinity can cost more:** with "prefer Spot" rules, the scheduler puts pods on the regular system node if it has room. The autoscaler then never adds a Spot node, and pods don't move back to Spot later. This is one of the main things Ocean fixes, and Phase 2 explains it.
- **The Ocean console may differ from my doc:** I couldn't check the current Flexera console, so Phase 4 uses the menu and Helm chart names I know. Copy exact commands from the console wizard. The same goes for the Ocean labels (`spotinst.io/node-lifecycle: od` and `spotinst.io/restrict-scale-down`): confirm they apply to AKS.
- **Playground permission limits:** if KodeKloud blocks the Spot quota or the hidden `MC_` resource group, Phase 3 has a fallback that uses `kubectl drain`. Note anything blocked in that phase's `doubts/` folder.