# Questions to Ask the Team About the Flexera Spot Adoption

Use these in stand-ups, 1:1s or the adoption channel. Write the answers right here, under each question, so this file becomes your map of the office setup.

---

## Scope and goals

- [ ] What's the main goal: cost reduction, autoscaling improvements, cost visibility, or all three?
- [ ] Which AKS clusters are in scope? Are we starting with **dev/test** before prod?
- [ ] What's the savings target, and how is it measured (Ocean savings report, Azure Cost Management, FinOps dashboard)?
- [ ] What's the timeline and rollout order (cluster by cluster, namespace by namespace)?

## Architecture and setup

- [ ] Are we using **Ocean** (full node management) or only cost visibility / right-sizing at first?
- [ ] What's the target **Spot percentage** per cluster (for example 70% Spot / 30% on-demand)?
- [ ] Is **fallback to on-demand** enabled? Is there a cap on on-demand spend?
- [ ] Which **VM sizes** are allowed in the Virtual Node Groups, and who decides?
- [ ] How many VNGs per cluster, and what do they separate (teams, workload types, GPU)?
- [ ] Is **headroom** configured? Automatic or manual?
- [ ] Has the **AKS cluster autoscaler** been disabled on migrated pools? What about pools not migrated yet?
- [ ] Do the existing reserved instances / savings plans still cover the on-demand part?

## Security and access

- [ ] Which **custom role permissions** does the Flexera app registration have? Who approved them?
- [ ] How is the **client secret** stored and rotated? Is it federated or certificate-based?
- [ ] Who has access to the **Flexera Spot console**, and with which roles? Can I get read-only or sandbox access?
- [ ] How is the **Ocean controller** deployed: Helm by hand, ArgoCD/GitOps, or Terraform?

## Workloads

- [ ] Which workloads are **excluded** from Spot (Kafka, databases, singletons)? Is the list written down?
- [ ] Is there a **Spot-readiness checklist** teams must pass (replicas, PDB, graceful shutdown)?
- [ ] How do teams opt in or out: tolerations, `spotinst.io/node-lifecycle: od`, a namespace policy?
- [ ] Are there policies (Azure Policy / Gatekeeper / Kyverno) enforcing PDBs or tolerations?
- [ ] Is anyone acting on Ocean's **right-sizing** recommendations, or are they just reported?

## Operations

- [ ] How do we **detect and alert** on evictions and node replacements (Azure Monitor, Prometheus, Ocean notifications)?
- [ ] What's the runbook when the Ocean controller is down or loses its heartbeat?
- [ ] What's the runbook when Spot capacity is unavailable in a region or zone?
- [ ] How are **AKS upgrades** handled with Ocean-managed nodes (node image and Kubernetes version roll)?
- [ ] Who's on call for Ocean-related incidents: platform team, FinOps, or app teams?

## Where I can help

- [ ] Can I own a **Spot-readiness review** for a few namespaces, using the Phase 5 checklist?
- [ ] Can I help move a dev cluster or namespace onto Ocean and document the steps?
- [ ] Can I build an evictions/savings dashboard or an alert?

---

## Notes from conversations

| Date | Who | What I learned |
|---|---|---|
| | | |
